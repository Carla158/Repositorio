from setuptools import setup
setup(
    name = "PaqueteParientes", 
    version="1.0",
    description="entregable MTV",
    author="Car",
    author_email="carlariverofernandez@gmail.com",
    packages=["PaqueteParientes"]
)
#py setup.py sdist (para que genere el .gz que es el que se comparte)